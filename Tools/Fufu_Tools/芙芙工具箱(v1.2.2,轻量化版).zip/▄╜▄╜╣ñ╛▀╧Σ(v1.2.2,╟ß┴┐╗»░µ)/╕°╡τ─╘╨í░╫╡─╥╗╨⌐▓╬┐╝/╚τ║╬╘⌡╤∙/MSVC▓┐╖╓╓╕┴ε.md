# 部分Microsoft Visual Code的指令<br>
运行指令 `Ctrl` + `Shift` + `P`<br>
多行末尾添加 `Shift` + `Alt` + `i`<br>